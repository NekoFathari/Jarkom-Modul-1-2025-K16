#!/bin/bash

echo "Selamat datang di Soal no 6"
echo "Wget sedang dijalankan..."
apt update && apt install -y wget

wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=1bE3kF1Nclw0VyKq4bL2VtOOt53IC7lG5' -O soal6.zip
echo "Proses download selesai."
echo "Ekstrak file soal6.zip..."
unzip soal6.zip 
echo "Ekstrak selesai."
echo "Jalankan script traffic.sh untuk memulai simulasi traffic."
chmod 777 traffic.sh
clear

echo "Sebelum menjalakan, pastikan anda sudah dalam packet capture di Wireshark"
read -p "Tekan [Enter] untuk melanjutkan..."
./traffic.sh
echo "Simulasi traffic selesai."
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 6"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."
echo "==============================="
exit 0

