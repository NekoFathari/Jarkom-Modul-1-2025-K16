#!/bin/bash

echo "Selamat datang di Soal no 7"
echo "Mulai menjalankan script..."
echo "==============================="

# Memastikan vsftpd terinstal
apt update && apt install -y vsftpd
echo "vsftpd sudah terinstal."

# Konfigurasi user ainur dan melkor
echo "Membuat user ainur dan melkor..."
useradd -m ainur
## Set password untuk user ainur yaitu ainur 
echo "ainur:ainur" | chpasswd
# Direktori home yang dimiliki root (Wajib untuk vsftpd keamanan modern)
mkdir -p /home/ainur/ftp_root && chown root:root /home/ainur/ftp_root && chmod 555 /home/ainur/ftp_root

# Direktori untuk file bersama (tempat ainur bisa menulis)
mkdir /home/ainur/ftp_root/share_files && chown ainur:ainur /home/ainur/ftp_root/share_files && chmod 775 /home/ainur/ftp_root/share_files
usermod -d /home/ainur/ftp_root ainur

echo "User ainur sudah dibuat."
echo "Membuat user melkor..."
useradd -m melkor
## Set password untuk user melkor yaitu melkor
echo "melkor:melkor" | chpasswd
mkdir -p /home/melkor/no_access && chown root:root /home/melkor/no_access && chmod 500 /home/melkor/no_access && usermod -d /home/melkor/no_access melkor
cd /home/ainur/ftp_root/ && chmod u-w share_files && chmod 555 share_files

echo "User melkor sudah dibuat."
echo "Merestart layanan vsftpd..."
service vsftpd restart
echo "Layanan vsftpd sudah direstart."
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 7"
echo "Script selesai dijalankan."
echo "==============================="
exit 0