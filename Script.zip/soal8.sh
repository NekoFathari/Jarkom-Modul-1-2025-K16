#!/bin/bash

echo "Selamat datang di Soal no 8"
echo "Mulai menjalankan script..."
echo "==============================="
echo "Memastikan wget dan unzip terinstal..."
apt update && apt install -y wget unzip
echo "Wget dan Unzip sudah terinstal."

# Mengunduh file cuaca.zip dari Google Drive
echo "Menjalankan Wget untuk mengunduh file cuaca.zip..."
wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=11ra_yTV_adsPIXeIPMSt0vrxCBZu0r33' -O cuaca.zip
echo "Proses download selesai."

# Mengekstrak file cuaca.zip
echo "Ekstrak file cuaca.zip..."
unzip cuaca.zip
echo "Ekstrak selesai."

# Upload file cuaca.txt ke FTP server
echo "Upload file cuaca.txt ke FTP server..."
# pastikan ftp sudah terinstall
apt install -y ftp

echo "Sebelum upload, pastikan anda sudah dalam packet capture di Wireshark"
read -p "Tekan [Enter] untuk melanjutkan..."
    
echo "Mulai upload file cuaca.txt dan mendung.jpg ke FTP server..."
# FTP konek ke 192.219.1.1 port 21 dengan user ainur dan password ainur
ftp -inv 192.219.1.1 21 <<EOF
user ainur ainur
put cuaca.txt
put mendung.jpg
quit
EOF

echo "Upload selesai."
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 8"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."
echo "==============================="
exit 0
    