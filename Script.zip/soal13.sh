#!/bin/bash

echo "Selamat datang di Soal no 13"
echo "1. Script untuk Eru"
echo "2. Script untuk Verda"
read -p "Pilih opsi (1 atau 2): " opsi
if [ "$opsi" == "1" ]; then
    # Opsi 1: Script untuk Eru
    echo "Memulai setup untuk Eru..."
    apt update && apt install -y ssh
    echo "Connect ke SSH Verda (192.216.2.2) port 22"
    echo "Sebelum menjalakan, pastikan anda sudah dalam packet capture di Wireshark"
    read -p "Tekan [Enter] untuk melanjutkan..."
    echo "Ketik 'ssh verda@192.216.2.2' untuk terhubung ke Verda"
    echo "Dengan user eru dan password eru"

elif [ "$opsi" == "2" ]; then
    # Opsi 2: Script untuk Verda
    echo "Memulai setup untuk Verda..."
    apt update && apt install -y openssh-server && service ssh start

    echo "Menambahkan user eru dengan password eru"
    useradd eru
    echo "eru:eru" | chpasswd
    echo "Setup untuk Verda selesai. Silahkan lanjut ke Eru."
else
    # Opsi tidak valid
    echo "Opsi tidak valid. Silakan jalankan script lagi dan pilih 1 atau 2."
    exit 1
fi
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 13"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."
echo "==============================="
exit 0