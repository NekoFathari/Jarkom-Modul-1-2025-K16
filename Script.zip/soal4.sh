#!/bin/bash

echo "Selamat datang di Soal no 4"
echo "Mulai menjalankan script..."
echo "==============================="

echo "nameserver 192.168.122.1" > /etc/resolv.conf
echo "nameserver sudah disetup."
echo "ping ke google.com untuk memastikan koneksi internet"
ping -c 10 google.com
echo "Ping selesai."
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 4"
echo "Script selesai dijalankan."
echo "==============================="
exit 0
