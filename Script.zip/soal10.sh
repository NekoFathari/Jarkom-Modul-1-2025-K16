#!/bin/bash

echo "Selamat datang di Soal no 10"
echo "Mulai menjalankan script..."
echo "==============================="

echo "Sebelum menjalakan, pastikan anda sudah dalam packet capture di Wireshark"
read -p "Tekan [Enter] untuk melanjutkan..."

echo "Menjalankan perintah ping -f ke Eru (192.219.1.1)"
ping -f 192.219.1.1 -c 5000
echo "Perintah ping -f selesai dijalankan."
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 10"
echo "Seharusnya tidak ada packet loss pada hasil capture! :)"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."
echo "==============================="

exit 0