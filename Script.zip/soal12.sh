#!/bin/bash

echo "Selamat datang di Soal no 12"
echo "1. Script untuk Eru"
echo "2. Script untuk Melkor"
read -p "Pilih opsi (1 atau 2): " opsi
if [ "$opsi" == "1" ]; then
    # Opsi 1: Script untuk Eru
    echo "Memulai setup untuk Eru..."
    apt update && apt install -y netcat-openbsd
    ## jalankan netcat port 23 80 dan 666 dengan timeout 10 detik
    echo "Menjalankan netcat di port 23, 80, dan 666 dengan timeout 10 detik..."
    netcat -vz 192.219.1.1 23 -w 10
    netcat -vz 192.219.1.1 80 -w 10
    netcat -vz 192.219.1.1 666 -w 10
if [ "$opsi" == "2" ]; then
    # Opsi 2: Script untuk Melkor
    echo "Memulai setup untuk Melkor..."
    apt update && apt install -y ufw apache2 vsftpd
    echo "Mengaktifkan UFW dan membuka port 23, 80, dan close port 666..."
    ufw allow 23
    ufw allow 80
    ufw deny 666
    ufw enable
    echo "Setup untuk Melkor selesai. Silahkan lanjut ke Eru."
else
    # Opsi tidak valid
    echo "Opsi tidak valid. Silakan jalankan script lagi dan pilih 1 atau 2."
    exit 1
fi
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 12"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."
echo "==============================="
exit 0

    