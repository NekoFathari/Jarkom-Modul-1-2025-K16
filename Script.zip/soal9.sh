#!/bin/bash

echo "Selamat datang di Soal no 9"
echo "Mulai menjalankan script..."
echo "==============================="

# Memastikan Wget dan Unzip terinstal
apt update && apt install -y wget unzip
echo "Wget dan Unzip sudah terinstal."

# Mengunduh file soal9.zip dari Google Drive
echo "Menjalankan Wget untuk mengunduh file soal9.zip..."
wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=11ua2KgBu3MnHEIjhBnzqqv2RMEiJsILY' -O soal9.zip
echo "Proses download selesai."
# Mengekstrak file soal9.zip
echo "Ekstrak file soal9.zip..."
unzip soal9.zip
echo "Ekstrak selesai."

# upload file ke FTP server dengan ainur
echo "Upload file ke FTP server..."
# pastikan ftp sudah terinstall
apt install -y ftp
echo "Sebelum upload, pastikan anda sudah dalam packet capture di Wireshark"
read -p "Tekan [Enter] untuk melanjutkan..."
echo "Mulai upload file ke FTP server..."

cp kitab_penciptaan.txt /home/ainur/ftp_root/share_files/

echo "Upload selesai."

echo "Kita buat user ainur hanya read only"
cd /home/ainur/ftp_root/
chmod u-w share_files

echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 9"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."

echo "==============================="