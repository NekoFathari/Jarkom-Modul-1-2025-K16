#!/bin/bash

echo "Selamat datang di Soal no 3"
echo "Mulai menjalankan script..."
echo "==============================="  
#ping all ip, 192.219.1.1-2 dan 192.219.2.1-2
for i in {1..2}; do
    ping -c 10 192.219.1.$i
    ping -c 10 192.219.2.$i
done
echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 3"
echo "Jangan lupa untuk mengamati hasil capture di Wireshark"
echo "Script selesai dijalankan."
echo "==============================="
exit 0
