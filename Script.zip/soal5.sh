#!/bin/bash

#Opsi pilihan 1 hingga 2
echo "Selamat datang di Soal no 5"
echo "1. Setup untuk Eru / Router"
echo "2. Setup untuk Client"
read -p "Pilih opsi (1 atau 2): " opsi
if [ "$opsi" == "1" ]; then
    # Opsi 1: Setup untuk Eru / Router
    echo "Memulai setup untuk Eru / Router..."

    apt update
    echo "apt update && apt install -y iptables vsftpd telnet netcat-openbsd unzip ssh" >> /root/.bashrc
    echo "iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE -s 192.219.0.0/16" >> /root/.bashrc

    # Konfigurasi FTP
    echo "write_enable=YES" >> /etc/vsftpd.conf
    echo "chroot_local_user=YES" >> /etc/vsftpd.conf

    # Restart layanan vsftpd
    systemctl restart vsftpd

    echo "Setup untuk Eru / Router selesai. Silahkan lanjut ke Setup Client."
elif [ "$opsi" == "2" ]; then
    # Opsi 2: Setup untuk Client
    echo "Memulai setup untuk Client..."
    # masukan nameserver sendiri atau bawaan otomatis
    echo "Pilih nameserver untuk resolusi DNS:"
    echo "1. Gunakan nameserver bawaan (192.168.122.1)
    echo "2. Input nameserver sendiri"
    read -p "Pilih opsi (1 atau 2): " dns_option
    if [ "$dns_option" == "1" ]; then
        echo "nameserver 192.168.122.1" > /etc/resolv.conf
    elif [ "$dns_option" == "2" ]; then
        read -p "Masukkan alamat nameserver: " custom_dns
        # Anda yakin dengan nameserver yang dimasukkan?
        read -p "Anda yakin ingin menggunakan nameserver $custom_dns? (y/n): " confirm_dns
        if [ "$confirm_dns" == "y" ]; then
            echo "nameserver $custom_dns" > /etc/resolv.conf
        else
            echo "Setup nameserver dibatalkan. Gunakan nameserver bawaan."
            echo "nameserver 192.168.122.1" > /etc/resolv.conf
        fi
    else
        echo "Opsi tidak valid. Abort."
        exit 1
    fi
    echo "nameserver telah disetup."
    echo "apt update && apt install -y iptables telnet ftp unzip ssh" >> /root/.bashrc
    echo "Setup untuk Client selesai."
else
    echo "Opsi tidak valid. Silahkan jalankan ulang script dan pilih opsi 1 atau 2."
    exit 1
fi

echo "==============================="
echo "Terima kasih sudah mengerjakan soal no 5"
echo "Script selesai dijalankan."
echo "==============================="
exit 0